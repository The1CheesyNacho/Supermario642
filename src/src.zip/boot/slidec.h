#ifndef SLIDEC_H
#define SLIDEC_H

void slidstart(unsigned char *compress, unsigned char *decompress);

void decompress(void *mio0, void *dest);

#endif // SLIDEC_H
