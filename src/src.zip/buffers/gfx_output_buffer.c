#include <ultra64.h>
#include "gfx_output_buffer.h"

u64 gGfxSPTaskOutputBuffer[0x2000];
