#ifndef S2D_ERROR_H
#define S2D_ERROR_H

extern int s2d_check_align(int align);
extern int s2d_check_str(const char *str);

extern int s2d_error_y;

#endif