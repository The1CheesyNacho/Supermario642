#ifndef DEBUG_H
#define DEBUG_H

// #define init_cond (CONTROLLER_HELD_INPUT & R_CBUTTONS)
// #define tex_cond (CONTROLLER_HELD_INPUT & D_CBUTTONS)
// #define mtx_cond (CONTROLLER_HELD_INPUT & L_TRIG)
// #define spr_cond (CONTROLLER_HELD_INPUT & U_JPAD)
// #define deinit_cond (CONTROLLER_HELD_INPUT & U_CBUTTONS)
#define tex_cond (1)
#define mtx_cond (1)
#define spr_cond (1)
#define init_cond (1)
#define deinit_cond (1)

#endif
