#ifndef TEXSCROLL_H
#define TEXSCROLL_H

#include "src/game/texscroll/castle_grounds_texscroll.inc.h"
extern void scroll_textures();

#endif
