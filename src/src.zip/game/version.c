#include "version.h"
#include "src/game/version_data.h"

#if 0 // if your PC username isn't your real name feel free to uncomment
char __username__[] = __USERNAME__;
#endif
char __compiler__[] = __COMPILER__;
char __linker__[]   = __LINKER__;
