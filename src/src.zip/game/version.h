#ifndef VER_H
#define VER_H

#if 0 // if your PC username isn't your real name feel free to uncomment
extern char __username__[];
#endif
extern char __compiler__[];
extern char __linker__[];

#endif
