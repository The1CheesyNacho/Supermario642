#include "levels/castle_grounds/header.h"
#include "levels/castle_grounds/texscroll.inc.c"
void scroll_textures_castle_grounds() {
		scroll_castle_grounds();
}
