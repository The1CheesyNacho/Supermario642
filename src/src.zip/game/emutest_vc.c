#include "emutest_vc.h"

f32 round_double_to_float(f64 v) {
    return v;
}
