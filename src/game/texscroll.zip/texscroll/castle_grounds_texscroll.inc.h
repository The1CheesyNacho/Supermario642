#include "levels/castle_grounds/texscroll.inc.h"
extern void scroll_textures_castle_grounds();
