#include "anim_050006AC.inc.c"
