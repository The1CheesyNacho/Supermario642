// 0x05002D68
const struct Animation *const spindrift_seg5_anims_05002D68[] = {
    &spindrift_seg5_anim_050006AC,
    NULL,
    NULL,
    NULL,
};
