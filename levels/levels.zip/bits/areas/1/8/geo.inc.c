// 0x0E0004C0
const GeoLayout bits_geo_0004C0[] = {
   GEO_CULLING_RADIUS(2700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07008D18),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
