// 0x0E000598
const GeoLayout bits_geo_000598[] = {
   GEO_CULLING_RADIUS(2200),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_0700DD00),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
