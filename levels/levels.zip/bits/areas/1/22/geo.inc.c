// 0x0E000610
const GeoLayout bits_geo_000610[] = {
   GEO_CULLING_RADIUS(1300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_070135A0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
