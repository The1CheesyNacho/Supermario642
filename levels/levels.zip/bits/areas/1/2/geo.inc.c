// 0x0E000430
const GeoLayout bits_geo_000430[] = {
   GEO_CULLING_RADIUS(3200),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07003670),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
