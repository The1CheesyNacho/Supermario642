// 0x0E000688
const GeoLayout bits_geo_000688[] = {
   GEO_CULLING_RADIUS(1900),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07014C28),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
