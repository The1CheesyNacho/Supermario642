#ifndef ENTRY_H
#define ENTRY_H

#include "types.h"

// script
extern const LevelScript level_script_entry[];

#endif
