// 0x07000000 - 0x07000800
ALIGNED8 static const Texture wmotr_seg7_texture_07000000[] = {
#include "levels/wmotr/0.rgba16.inc.c"
};

// 0x07000800 - 0x07000C00
ALIGNED8 static const Texture wmotr_seg7_texture_07000800[] = {
#include "levels/wmotr/1.rgba16.inc.c"
};

// 0x07000C00 - 0x07001400
ALIGNED8 static const Texture wmotr_seg7_texture_07000C00[] = {
#include "levels/wmotr/2.rgba16.inc.c"
};

// 0x07001400 - 0x07001600
ALIGNED8 static const Texture wmotr_seg7_texture_07001400[] = {
#include "levels/wmotr/3.rgba16.inc.c"
};

// 0x07001600 - 0x07001800
ALIGNED8 static const Texture wmotr_seg7_texture_07001600[] = {
#include "levels/wmotr/4.rgba16.inc.c"
};
