// 0x0E000510
const GeoLayout bitfs_geo_000510[] = {
   GEO_CULLING_RADIUS(2600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bitfs_seg7_dl_07004630),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
