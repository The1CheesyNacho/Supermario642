// 0x0E000528
const GeoLayout bitfs_geo_000528[] = {
   GEO_CULLING_RADIUS(3500),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_07006B90),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
