// 0x0E0006F0
const GeoLayout bitfs_geo_0006F0[] = {
   GEO_CULLING_RADIUS(800),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_07010168),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
