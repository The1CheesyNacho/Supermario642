// 0x0E000788
const GeoLayout bitfs_geo_000788[] = {
   GEO_CULLING_RADIUS(800),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_07011E28),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
