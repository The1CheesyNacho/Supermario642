// 0x0E000678
const GeoLayout bitfs_geo_000678[] = {
   GEO_CULLING_RADIUS(400),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_0700F508),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
