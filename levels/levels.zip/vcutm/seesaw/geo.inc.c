// 0x0E0001F0
const GeoLayout vcutm_geo_0001F0[] = {
   GEO_CULLING_RADIUS(1000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, vcutm_seg7_dl_070096E0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
