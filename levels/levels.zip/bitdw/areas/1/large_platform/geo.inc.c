// 0x0E0003D8
const GeoLayout geo_bitdw_0003D8[] = {
   GEO_CULLING_RADIUS(2300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_070032F8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
