// 0x0E000438
const GeoLayout geo_bitdw_000438[] = {
   GEO_CULLING_RADIUS(2500),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bitdw_seg7_dl_070045C0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
