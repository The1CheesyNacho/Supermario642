#include "levels/bob/area_1/collision.inc.c"
#include "levels/bob/area_1/macro.inc.c"
#include "levels/bob/area_1/spline.inc.c"
#include "levels/bob/model.inc.c"
